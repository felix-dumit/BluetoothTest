//
//  Constants.h
//  BluetoothTest
//
//  Created by Felix Dumit on 7/4/15.
//  Copyright (c) 2015 BlueTest. All rights reserved.
//

#ifndef BluetoothTest_Constants_h
#define BluetoothTest_Constants_h

#define TRANSFER_SERVICE_UUID           @"9BACD244-D1DA-4CF3-A56B-F12064AD5EE1"
#define TRANSFER_CHARACTERISTIC_UUID    @"79EF7415-EEF9-4BE5-B779-7ACAE9761FF3"

#endif
